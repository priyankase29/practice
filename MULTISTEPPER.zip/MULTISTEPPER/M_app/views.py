from audioop import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import redirect, render
from M_app.models import Multistepper
from django.contrib import messages

# Create your views here.


def index(request):
     return render(request, 'M_app/index.html')

def save(request):
    if request.method!='POST':
        return redirect('/')
    else:
        email=request.POST.get('email')
        Password=request.POST.get('Password')
        cpass=request.POST.get('cpass')
        marks=request.POST.get('marks')
        pyear=request.POST.get('pyear')
        univ=request.POST.get('univ')
        fname=request.POST.get('fname')
        lname=request.POST.get('lname')
        cont=request.POST.get('cont')
        address=request.POST.get('address')
        gender=request.POST.get('gender')
        if Password!=cpass:
            messages.success(request, 'password not same')
            return redirect('/')

        try: 
            submitmulti=Multistepper(email=email,Password=Password,cpass=cpass,marks=marks,pyear=pyear,univ=univ,fname=fname,lname=lname,cont=cont,address=address,gender=gender)
            submitmulti.save()
            messages.success(request, 'Successfull')
            return redirect('/')
        except:
            messages.success(request, 'Error')
            return redirect('/')