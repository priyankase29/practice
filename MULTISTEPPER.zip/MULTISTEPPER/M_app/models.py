from django.db import models

# Create your models here.
class Multistepper(models.Model):
    id=models.AutoField(primary_key=True)
    email=models.CharField(max_length=255)
    Password=models.CharField(max_length=255)
    cpass=models.CharField(max_length=255)
    marks=models.CharField(max_length=255)
    pyear=models.CharField(max_length=255)
    univ=models.CharField(max_length=255)
    fname=models.CharField(max_length=255)
    lname=models.CharField(max_length=255)
    cont=models.CharField(max_length=255)
    address=models.CharField(max_length=255)
    CHOICES = [('M','Male'),('F','Female')]
    # Gender=models.CharField(label='Gender', widget=models.RadioSelect(choices=CHOICES))

    GENDER_CHOICES = (('M', 'Male'), ('F', 'Female'))
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, null=True)
    
    # objects=models.Manager()
    def __str__(self):
        return self.fname
